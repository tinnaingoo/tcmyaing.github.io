# tcmyaing.github.io

**For Download Button**
/*<a href="/files/securable.exe" download>
<button class="btn"><i class="fa fa-download"></i> Download</button>    
</a>*/
